
//Referencing Folder 15, day 3 activity 07
(async function getData(){
    //Grab info from the json file
    var importedData = await d3.json("samples.json");  //HELP correct way to direct it to the parent folder?
    console.log(importedData);
    var data = importedData;

    //Move this code to the function for graphing
    // Sort the data array
    data.sort(function(a, b) {
      return parseFloat(b. sample_values) - parseFloat(a.sample_values); //HELP not sure how to call into these correctly
    });
  
    // Slice the first 10 objects for plotting
    data = data.slice(0, 10);
  
    // Reverse the array due to Plotly's defaults
    data = data.reverse();
  
    // Trace1 for the Data
    var trace1 = {
      x: data.map(row => row.sample_values),
      y: data.map(row => row.samples.otu_ids),//HELP is this how to call it?
      text: data.map(row => row.otu_labels),
      name: "Top 10 OTUs found",
      type: "bar",
      orientation: "h"
    };

    // data
    var chartData = [trace1];

    // Apply the group bar mode to the layout
    var layout = {
        title: "Bar Graph",
        margin: {
        l: 100,
        r: 100,
        t: 100,
        b: 100
    }
  };
  // Render the plot to the div tag with id "plot"
  Plotly.newPlot("plot", chartData, layout);
});



  //Referencing Activity 9 from day 2
function buildMetadata(sample) {
    var sampledata = sample.metadata
    console.log(sampledata);
    var dropdownMenu = d3.selectAll("#sample-metadata");
    console.log(dropdownMenu);
    
    // Assign the value of the dropdown menu option to a variable
    var dataset = dropdownMenu.property("value");
    var data = [];
    
    // Use `.html("") to clear any existing metadata
    sample_metadata.html("");

    Object.entries(sampledata).forEach(function ([key,value]){
      const row = sample_metadata.append("p");
      row.text(`${key}: ${value}`);
    });
  };


function buildCharts(sample) {

    const
        x = plotdata.otu_ids;
        y = plotdata.sample_values;
        size = plotdata.sample_values;
        color = plotdata.otu_ids;
        labels = plotdata.otu_labels;
      
    const trace1 ={
      x:x,
      y:y,
      text:labels,
      mode:'markers',
      marker:{
          color: color,
          size: size,
          colorscale:"Rainbow" 
      }
    };
    const bubbledata = [trace1];
    
    const bubblelayout = {
    title: 'OTU ID',
    };

    Plotly.newPlot('bubble', bubbledata, bubblelayout);

};

function init() {
    // Grab a reference to the dropdown select element
    var selector = d3.select("#selDataset");

    // Use the list of sample names to populate the select options
      
    //var incomingData = await d3.json("samples.json");
    d3.json('./samples.json', function(error, data){
      console.log(data);
    })
    //console.log(incomingData);
    //d3.json("samples.json").then((sampleNames) => {
    // var names = sampleNames.names
    // names.forEach((sample) => {
    //     selector
    //     .append("option")
    //     .text(sample)
    //     .property("value", sample);
    // });

    // // Use the first sample from the list to build the initial plots
    // var firstSample = names[0];
    // console.log(firstSample);
    // buildCharts(firstSample);
    // buildMetadata(firstSample);
    // };
  };

function optionChanged(newSample) {
  // Fetch new data each time a new sample is selected
  buildCharts(newSample);
  buildMetadata(newSample);
}

// Initialize the dashboard
init();
